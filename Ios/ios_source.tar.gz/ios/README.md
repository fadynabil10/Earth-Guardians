gonative-ios
============

This is the native IOS code used by https://www.gonative.io/. It allows the creation of apps from existing mobile-optimized websites.

How to use
------------
Open project in Xcode. Edit appConfig.json as appropriate.

Licensing information available at https://gonative.io/.
